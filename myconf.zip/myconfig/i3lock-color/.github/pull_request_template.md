<!--
(Opional) What i3lock-color issue does this PR address? (for example, #1234)
-->
Closes #[issue number]

## Description
 -

### Screenshots/screencaps
<!--
Include screenshots or gifs if relevant.
-->

## Release notes
<!--
What to include in the notes section of an upcoming release that describes this PR.
If the PR doesn't to be mentioned in the release notes, put "Notes: no-notes".
-->
Notes:
